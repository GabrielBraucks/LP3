const CPF_MÁSCARA = "999.999.999-99";
export { CPF_MÁSCARA };
